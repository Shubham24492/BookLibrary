import React from 'react';
import {shallow} from 'enzyme';

function Hello(props){
    return <h1>Hello at {props.now}</h1>;
}


describe('When testing is up', ()=>{
    it('should fail', ()=>{
        expect(1+1).toBe(2);
    })
})

const moment  = new Date(1588946400000);

describe('When testing is directly', ()=>{
    beforeAll(()=>{
        result = Hello({now: moment.toISOString()});
    })

    it('return a value', ()=>{
        expect(result).not.toBeNull();
    })

    it('return a h1', ()=>{
        expect(result.type).toBe("h1");
    })
})

